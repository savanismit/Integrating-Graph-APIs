import logging, requests, json
from app import app, db
from flask import session, redirect, render_template, url_for, make_response, request
from .models import User
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import LoginManager, login_user, login_required, logout_user, current_user
from flask_restful import Resource, Api

api = Api(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


class index(Resource):
    def __init__(self):
        pass

    def get(self):
        return redirect(url_for('login'))


class login(Resource):
    def get(self):
        return make_response(render_template('login.html'))

    def post(self):
        user = User.query.filter_by(username=request.form["username"]).first()
        if user:
            if check_password_hash(user.password, request.form["password"]):
                login_user(user)
                return redirect(url_for('dashboard'))

        with open("app/json_files/error_messages.json") as f:
            errors = json.load(f)
        errors["error_message"] = 'Invalid Username or Password!'
        return make_response(render_template('login.html', errors=errors["error_message"]))


class signup(Resource):
    def get(self):
        return make_response(render_template('signup.html'))

    def post(self):
        firstname = request.form["firstname"]
        lastname = request.form["lastname"]
        username = request.form["username"]
        email = request.form["email"]
        password = request.form["password"]

        user = User.query.filter_by(username=request.form["username"]).first()
        if user:
            with open("app/json_files/error_messages.json") as f:
                errors = json.load(f)
            errors["error_message"] = 'User already exist. kindly login!'
            return make_response(render_template('login.html', errors=errors.get('error_message', {})))

        if password != request.form["confirmpassword"]:
            with open("app/json_files/error_messages.json") as f:
                errors = json.load(f)
            errors["error_message"] = 'Passwords do not match! Try again.'
            return make_response(render_template('signup.html', errors=errors.get('error_message', {})))

        hashed_password = generate_password_hash(password, method='sha256')
        new_user = User(firstname=firstname, lastname=lastname, username=username,
                        email=email, password=hashed_password)

        db.session.add(new_user)
        db.session.commit()
        return redirect(url_for('login'))


class logout(Resource):
    @login_required
    def get(self):
        session.clear()
        logout_user()
        return redirect(url_for('login'))


class dashboard(Resource):
    @login_required
    def get(self):
        return make_response(render_template('dashboard.html'))

api.add_resource(index, '/')
api.add_resource(login, '/login')
api.add_resource(signup, '/signup')
api.add_resource(logout, '/logout')
api.add_resource(dashboard, '/dashboard')
